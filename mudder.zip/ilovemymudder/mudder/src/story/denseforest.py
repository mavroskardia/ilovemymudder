name = 'Neverending Harsdenwood'

description = '''
	You have entered a portion of the Harsdenwood that has grown too thick to
	continue in any direction other than back towards the clearning.

	Maybe one day someone will come and clear a path, but not today.
'''

exits = {
	'north': 'src.story.clearing',
}