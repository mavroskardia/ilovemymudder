name = 'Entrance to the Undertown'

description = '''
	There is a massive hole in the ground with a vibrant market at the bottom.

	A wide staircase descends into the hole that no one finds peculiar at all.
'''

exits = {
	'down': 'src.story.undertown',
	'west': 'src.story.town_center',
}