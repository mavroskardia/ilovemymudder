from .client import Client


if __name__ == '__main__':
    Client().run()
